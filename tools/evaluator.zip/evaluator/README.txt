
This is a Python 3 application to evaluate powergrab.jar archives by running 
them on all available maps.  It requires that you install the xlsxwriter 
module with the command "pip install xlsxwriter" or similar.  

Place powergrab.jar in ../out/artifacts/powergrab.jar.  

Results are written to report.xlsx.
